import requests
import pandas as pd
from datetime import datetime
import schedule
import time

# Fonction pour récupérer des données météo depuis WeatherStack
def fetch_weather_data(city):
    api_key = "50ddabcb370eedaedb1575347260505f"  # Utilise ta clé API
    url = f"http://api.weatherstack.com/current?access_key={api_key}&query={city}"
    
    response = requests.get(url)
    
    if response.status_code == 200:
        print(f"Success! Data fetched for {city}.")
        return response.json()
    else:
        print(f"Failed to fetch data: {response.status_code}")
        return None

# Fonction pour stocker les données dans un fichier Excel
def store_weather_data(city):
    data = fetch_weather_data(city)
    
    if data:
        weather_data = {
            "city": city,
            "temperature": data["current"]["temperature"],
            "weather": data["current"]["weather_descriptions"][0],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        df = pd.DataFrame([weather_data])
        file_path = r'C:\Users\GAD2\Documents\Document Personnel\Privé\Perso\Espagnol\RavenPack\weather_data.xlsx'
        df_current = pd.read_excel(file_path, engine="openpyxl", sheet_name="Weather Data")
        pd.concat([df_current, df]).to_excel(file_path, index=False, engine="openpyxl", sheet_name="Weather Data")
            

        print("Data stored successfully.")
    else:
        print("No data to store.")

# Exécuter l'extraction immédiatement
store_weather_data("Paris")

## Planifier l'exécution de la collecte de données toutes les 2 heures
schedule.every(1).hours.do(store_weather_data, city="Paris")

## Boucle pour exécuter le processus d'automatisation
while True:
    schedule.run_pending()
    time.sleep(1)